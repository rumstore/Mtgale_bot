# HabrParser_Bot
Приложение к статье https://habrahabr.ru/post/350648/
